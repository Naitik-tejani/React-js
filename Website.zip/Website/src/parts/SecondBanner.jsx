import React from 'react'
import '../parts/Assetes/css/SecondBanner.css'

export default function () {
  return (
    <div>
      

        


    </div>
  )
}
